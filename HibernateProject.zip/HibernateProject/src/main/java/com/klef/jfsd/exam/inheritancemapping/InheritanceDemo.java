package com.klef.jfsd.exam.inheritancemapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class InheritanceDemo {
	public static void main(String aegs[])
	{
		Configuration cfg = new Configuration();
	    cfg.configure("hibernate.cfg.xml");
	    
	    SessionFactory sf  = cfg.buildSessionFactory();
	    Session session = sf.openSession();
	    
	    Transaction transcation =  session.beginTransaction();
	    
	    Vehicle v = new Vehicle();
        v.setName("Generic Vehicle");
        v.setType("Generic");
        v.setMaxspeed("100 km/h");
        v.setColor("Blue");

        Car c = new Car();
        c.setName("Sedan");
        c.setType("Car");
        c.setMaxspeed("180");
        c.setColor("Red");
        c.setNoofdoors(4);

        Truck t = new Truck();
        t.setName("Cargo Truck");
        t.setType("Truck");
        t.setMaxspeed("120 ");
        t.setColor("Green");
        t.setLoadcapacity(10000);

        // Save objects
        session.save(v);
        session.save(c);
        session.save(t);

	 
	   
	   System.out.println("SUCCESS.....!!!");
	   
	   
	 
	    
	    
	    transcation.commit();
	    sf.close();
	    session.close();
	    
	}

}
